# Deckblatt

# Prognostisches Potenzial von CD44 als Tumorstammzellmarker für die kombinierte Radiochemotherapie des lokal fortgeschrittenen Kopf-Hals-Plattenepithelkarzinoms

> Aus der Klinik für Strahlentherapie und Radioonkologie
> Direktorin: Prof. Dr. Mechthild Krause
>
> **Dissertationsschrift**
>
> zur Erlangung des akademischen Grades

Doktor*in der Medizin

Doctor medicinae (Dr. med.)

vorgelegt

der Medizinischen Fakultät Carl Gustav Carus
der Technischen Universität Dresden

von

Martin Jütz

aus Nauen

Dresden, 2024

gez. ____________
Vorsitzende*r der Promotionskommission

1. Gutachter*in:
2. Gutachter*in:

Tag der mündlichen Prüfung: ____________

Die wissenschaftliche Analyse zeigt, dass anmerkung:**.
Die Eintragung der Gutachter*innen und des Tages der mündlichen Prüfung (Verteidigung) erfolgt nach Festlegung durch die Medizinische Fakultät Carl Gustav Carus der TU Dresden. Sie wird durch die Promovierenden nach der Verteidigung zwecks Übergabe der fünf Pflichtexemplare an die Zweigbibliothek Medizin in gedruckter Form oder handschriftlich vorgenommen.
