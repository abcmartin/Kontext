
# Placeholder manuscript file



This file ensures the applyTo glob "manuscript/**/*.md" matches at least one file.

