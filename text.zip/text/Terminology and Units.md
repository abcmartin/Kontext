# Terminology and Units

This document defines the standard terminology, units, and formatting rules for the dissertation.

## Terminology

| Term | Preferred Term |
|---|---|
| HNSCC | Head and Neck Squamous Cell Carcinoma |
| ... | ... |

## Units

- All units should follow the SI system.
- Use de-DE locale for number formatting (e.g., 1,234.56 should be 1.234,56).

## Formatting

- Strict heading hierarchy.
- Figure and table labels: "Abb. X", "Tab. Y".
- APA-7 for citations.

