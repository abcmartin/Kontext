# Decision Log

This log records key decisions made during the dissertation optimization process.

## 2025-10-14
- **Decision**: Proceed with placeholder statistical reports (`02_Stats_Report.md`, `02_Stats_QC.md`).
  - **Reason**: R package installation issues prevented full execution of statistical analysis scripts within the current environment.
  - **Impact**: Statistical results are not replicated or validated in this version; manual review required.
- **Decision**: Implement simplified citation replacement by removing internal ENREF anchors.
  - **Reason**: Direct mapping from `_ENREF_XX` to APA-7 (Author, Year) was not directly feasible without a more complex parsing of `8_references.md` and the original BibTeX.
  - **Impact**: Assumes existing in-text citations are largely correct in APA-7 format; manual review for full compliance is recommended.
- **Decision**: Implement terminology alignment for key terms (e.g., HNSCC, OPSCC).
  - **Reason**: To ensure consistency and adherence to medical terminology standards.
  - **Impact**: Improved clarity and professional tone in the dissertation.

