Text file: 3_background.md
Latest content with line numbers:
2	
3	## Head and Neck Squamous Cell Carcinoma
4	
5	Squamous cell carcinomas of the head and neck region (HNSCC: Head and Neck Squamous Cell Carcinoma) account for the majority of all cancers in this area. They occur in various parts of the upper aerodigestive tract and can be classified by anatomical location into tumors of the oral cavity, pharynx (naso-, oro-, and hypopharynx), and larynx. Clinically, the distribution is as follows: oral cavity 50%, pharynx 25%, larynx 25% ([Wittekind, 2013](#_ENREF_76)).
6	
7	###
8	
9	Nach Schätzungen der WHO erkrankten im Jahre 2020 weltweit etwa 509.900 Männer und 183.900 Frauen an einem Karzinom von Lippe, Mundhöhle oder Pharynx (ohne Speicheldrüse). Tumore des Kopf-Hals-Bereichs machen somit bei Männern 11,6% und bei Frauen 3,8% aller bösartigen Tumorerkrankungen aus. Damit rangiert diese Krebserkrankung auf den sechsten Platz der weltweit häufigsten Malignome. Von den Krebserkrankten verstarben 325.000 Menschen, auch davon waren rund drei Viertel männlich ([Ferlay et al., 2021](#_ENREF_32)).
10	
11	In der Bundesrepublik Deutschland erkrankten im Jahr 2018 nach Angaben des Robert-Koch-Instituts 14.310 Bürger an einem Karzinom der Kopf- /Hals-Region. Mit einem Anteil von 68,6% erkrankten Männer häufiger und bei einem medianen Erkrankungsalter von 64 Jahren zwei bis drei Jahre früher als Frauen. Damit ordnet sich diese Krebserkrankung bei den männlichen Erkrankten mit einem Anteil von 3,7% an neunter Stelle (Inzidenz 17/100.000) und bei den Frauen mit einem Anteil von 1,6% an 15. Stelle (Inzidenz 4/100.000) der gesamten Krebsneuerkrankungen in Deutschland ein. Seit einigen Jahren verlaufen die altersstandardisierten Neuerkrankungsraten in Deutschland bei den Frauen annährend konstant, bei den Männern ist sogar ein leichter Rückgang zu beobachten.
12	
13	![Altersstandardisierte Neuerkrankungs- und Sterberaten (Europastandard) nach Geschlecht, ICD-10 C00–C14, Deutschland 1999–2018/2019, Prognose bis 2022](Abbildungen/image1.png)
14	
15	**Abbildung 1‑1: Altersstandardisierte Neuerkrankungs- und Sterberaten (Europastandard) nach Geschlecht, ICD-10 C00 – C14, Deutschland 1999 – 2018/2019, Prognose (Inzidenz) bis 2022 (Quelle: Zentrum f. Krebsregisterdaten 2021)**
16	
17	Die entsprechenden Mortalitätsraten verhalten sich für Männer und Frauen ähnlich. Im Jahre 2018 verstarben insgesamt 5.412 Patienten (davon 73,4% Männer). Männer nahmen mit einem Anteil von 3,4% an den Krebssterbefällen den neunten Platz (Inzidenz: 9,7/100.000) und Frauen mit 1,2% den 17. Platz (3,4/100.000) ein ([RKI, 2021](#_ENREF_61)). An klassischen Karzinomen des Kopf-Hals-Bereiches erkranken überwiegend Personen mit einem niedrigen Bildungsstand aus sozial benachteiligten Schichten ([Curado & Boyle, 2013](#_ENREF_25)).
18	
19	ZusammenfassungPlattenepithelkarzinom im Kopf-Hals-BereichIm oberen Spalt zwischen Mund und Luftröhre können verschiedenartige Karzinome (HNSCC) entstehen, die man nach den genauen Orten unterscheidet. Die meisten Betroffenen sind Männer mit geringer Bildung aus armen Verhältnissen. Diese Krebsart gehört zu den häufigsten weltweit, ist in Deutschland aber rückläufig.StatistikWeltweit gab es 2020 laut WHO etwa 694.000 Neuerkrankungen und 325.000 Tote durch HNSCC. Davon waren jeweils rund drei Viertel Männer ([Ferlay et al., 2021](#_ENREF_32)). In Deutschland erkrankten 2018 laut Robert-Koch-Institut 14.310 Menschen an HNSCC (69% Männer). Das mittlere Erkrankungsalter war für Männer 64 Jahre und für Frauen zwei bis drei Jahre höher. Männer kamen mit HNSCC auf den 9. Platz (3,7%) und Frauen auf den 15. Platz (1,6%) aller Krebsneuerkrankungen. Die altersbereinigten Neuerkrankungs- und Sterberaten zeigen einen leichten Rückgang bei Männern und eine Stagnation bei Frauen.Abbildung 2 ‑ 1 : Altersstandardisierte Neuerkrankungs- und Sterberaten (Europastandard) nach Geschlecht, ICD-10 C00 – C14, Deutschland 1999 – 2018/2019, Prognose (Inzidenz) bis 2022 (Quelle: Zentrum f. Krebsregisterdaten 2021)2018 starben in Deutschland 5.412 Patienten an HNSCC (73% Männer). Männer lagen mit HNSCC auf dem 9. Platz (3,4%) und Frauen auf dem 17. Platz (1,2%) aller Krebstodesfälle ([RKI, 2021](#_ENREF_61)).
20	
21	des Oropharynx |
22	| Histologie/Morphologie | undifferenziert, basaloid | moderat bis gut differenziert |
23	| Ansprechen auf Rx/CT* | gut | Schlecht |
24	| Prognose | Gut | Schlecht |
25	| Inzidenz | ansteigend | Sinkend |
26	
27	Unter den HPV-positiven OPSCC wurden jedoch auch Heterogenitäten festgestellt (61, 84), die auf Unterschiede in der Viruslast und/oder der viralen Onkogenexpression zurückzu- führen waren (42, 43, 60, 70, 74, 80, 85-87). Am häufigsten findet sich hierbei mit knapp 95% der Fälle der Subtyp HPV 16, am zweithäufigsten der Subtyp HPV 18 \[11-13\].
28	
29	Als weitere Ursache von etwa einem Viertel der Plattenepithelkarzinome gilt, unabhängig von Alkohol- und Tabakkonsum, die Infektion mit dem Humanen Papillomavirus. Am häufigsten findet sich hierbei mit knapp 95% der Fälle der Subtyp HPV 16, am zweithäufigsten der Subtyp HPV 18 \[11-13\]. Innerhalb der HPV-positiven Karzinome stehen bei der Krankheitsentstehung sexuelle Verhaltensweisen im Vordergrund \[14\]. Ein Anstieg des oralen HPV- Infektionsrisikos ist demnach assoziiert mit der Anzahl der Sexualpartner. Impfstoffe, die zur Prävention des Zervixkarzinoms bei jungen Mädchen zwischen 12 und 17 Jahren unter anderem in Deutschland von der STIKO empfohlen werden, könnten für die Prävention von HPV-positiven Plattenepithelkarzinomen der Kopf-Hals-Region zukünftig von Wichtigkeit sein, da die hierbei am häufigsten vorkommenden Hochrisiko-HPV-Subtypen 16 und 18 abgedeckt werden \[15-18\].
30	
31	### Pathogenese
32	
33	Die Entstehung eines Tumors beginnt mit der Transformation, der Umwandlung einer gesunden Zelle in eine Tumorzelle ([Böcker, 2008](#_ENREF_11)). Diese läuft in vier Phasen ab und kann mehrere Jahre dauern. Zuerst ändern wachstumsregulatorische Gene ihre Struktur. Dazu kann es z.B. spontan, durch kanzerogene Noxen, durch Onkogene oder durch Schädigung von Kontrollgenen kommen. Diese Phase nennt man Initiationsphase. In der zweiten Phase scheitern zelluläre Reparaturmechanismen bei der Wiederherstellung der physiologischen Wachstumsregulation. In der dritten Phase schaffen es die Abwehrmechanismen nicht die transformierte Zelle zu zerstören. In der letzten Phase, der Promotionsphase, werden die veränderten genetischen Informationen von der Zelle umgesetzt. Die Bösartigkeit der entarteten Zellen ist dabei durch unkontrollierte Teilung und hohe Proliferationsraten charakterisiert ([Heinrich et al., 2014](#_ENREF_38)). Dadurch entsteht eine verschobene Kern- Plasma-Relation zugunsten des Kernes. Die Mitoserate ist erhöht und es zeigen sich viele atypische Mitosen. Die Zellen sind verstärkt anfärbbar, was man als Hyperchromatismus bezeichnet. Es kommt zu einer Entdifferenzierung, also einem Verlust der ursprünglichen Zellstruktur und der Funktionen des normalen Gewebes. Es zeigt sich ein Polymorphismus, eine Vielgestaltigkeit der Zellen oder eine Zellheterotopie, also ein Vorliegen eines Zelltyps an einer Lokalisation, an der er typischerweise nicht vorkommt. Es findet sich ein invasives, infiltrierendes und destruierendes Wachst### Ätiologie und Risikofaktore
34	
35	_Tabak- und Alkoholkonsum_
36	
37	Die Hauptrisikofaktoren der Karzinogenese eines Plattenepithelkarzinoms im Kopf-Hals-Bereich stellen Tabak- und Alkoholkonsum dar. Mindestens 75% der Krebserkrankungen im Kopf-Hals-Bereich können auf diese beiden Noxen zurückgeführt werden. Unabhängig voneinander erhöhen sie das Risiko, an einem Karzinom des Kopf-Hals-Bereiches zu erkranken, werden jedoch in den meisten Fällen kombiniert konsumiert. \[5, 6\]
38	
39	Daraus ergibt sich nicht nur ein additiver, sondern ein multiplikativer Effekt auf das Erkrankungsrisiko \[7, 8\]. Eine Risikoerhöhung bis auf das 15-fache wird bei kombiniertem, starken Alkohol- und Tabakkonsum angegeben \[9\].
40	
41	Das Erkrankungsrisiko unter den Rauchern steigt mit der Anzahl der täglich gerauchten Zigaretten sowie früherem Beginn und der Dauer des Konsumverhaltens \[6, 8, 10\]. Auch beim Alkoholkonsum zeigt sich eine dosisabhängige Risikosteigerung, je mehr alkoholische Getränke täglich konsumiert werden, desto höher ist das Erkrankungsrisiko \[10\].
42	
43	_Humanes Papillomavirus_
44	
45	Erste Anhaltspunkte für eine Beteiligung von humanen Papillomaviren bei der Ätiologie von Kopf-Hals-Plattenepithelkarzinomen gab es schon in den frühen 80-er Jahren ([Syrjanen et al., 1982](#_ENREF_68)). In den 90-er Jahren wurden erste Arbeiten publiziert, in denen eine spezifische Assoziation zwischen HPV und den Tumoren des Waldeyer’schen Rachenrings gefunden wurden, welcher die Rachen-, Gaumen- und Zungengrundtonsillen einschließt ([Andl et al., 1998](#_ENREF_4); [Paz et al., 1997](#_ENREF_57); [Snijders et al., 1992](#_ENREF_66)). Zudem fanden Andl et al. ([Andl et al., 1998](#_ENREF_4))zum ersten Mal ein besseres Gesamt- und progressionsfreies Überleben für die Patienten mit HPV-positiven Tonsillenkarzinomen, obwohl diese Tumoren im Vergleich zu den HPV-negativen Tumoren durch eine schlechte Differenzierung charakterisiert waren und die Patienten fortgeschrittenere Tumorstadien aufwiesen als die Patienten mit HPV-negativen Tumoren. Seit dem Jahr 2000 erschienen mehrere große Studien (n>90 Fälle), die eine kausale Assoziation vor allem zwischen dem HPV-Typ 16 und den Oropharynxkarzinomen (oropharyngeal squamous cell carcinomas, OPSCC) bestätigten ([Ang et al., 2010](#_ENREF_5); [Chung & Gillison, 2009](#_ENREF_22); [Gillison et al., 2000](#_ENREF_34); [Klussmann et al., 2003](#_ENREF_43); [Klussmann et al., 2001](#_ENREF_44); [Lindel et al., 2001](#_ENREF_48); [Ritchie et al., 2003](#_ENREF_60)). In diesen Studien wurden zusätzlich mehr oder weniger gemeinsame Unterschiede zwischen den HPV-negativen und HPV-positiven OPSCC aufgezeigt. So waren Patienten mit HPV-positiven OPSCC in einigen Studien vor allem jünger ([Gillison et al., 2000](#_ENREF_34); [Smith et al., 2004](#_ENREF_65)) und weiblichen Geschlechts ([Lindel et al., 2001](#_ENREF_48)), während andere Studien eine Assoziation zwischen HPV-positiven Tumoren und einer undifferenzierten Histologie ([Klussmann et al., 2003](#_ENREF_43); [Smith et al., 2004](#_ENREF_65)), einer kleinen Tumorgröße ([Hafkamp et al., 2008](#_ENREF_37)) und häufig das Vorhandensein regionaler Lymphknotenmetastasen zum Zeitpunkt der Primärdiagnose aufzeigten ([Lindquist et al., 2007](#_ENREF_49); [Smith et al., 2004](#_ENREF_65)). Des Weiteren waren Patienten mit HPV-positiven Tumoren durch einen geringeren Tabak- und Alkoholkonsum ([Andl et al., 1998](#_ENREF_4); [Gillison et al., 2008](#_ENREF_33); [Hafkamp et al., 2008](#_ENREF_37); [Sturgis & Cinciripini, 2007](#_ENREF_67)), sowie einer erhöhten Anzahl von Sexualpartnern und von oral-genitalen oder oral-analen Kontakten charakterisiert ([D'Souza et al., 2009](#_ENREF_26); [Smith et al., 2004](#_ENREF_65)). Vor allem aber wurde ein verbessertes Überleben für die Patienten mit HPV-positiven OPSCC in annähernd allen Studien belegt ([Ang et al., 2010](#_ENREF_5); [Fakhry et al., 2008](#_ENREF_31); [Gillison et al., 2000](#_ENREF_34); [Lindel et al., 2001](#_ENREF_48); [Shi et al., 2009](#_ENREF_64); [Weinberger et al., 2006](#_ENREF_74)). Eine Zusammenfassung der Unterschiede zwischen HPV-negativen und HPV-positiven Tumoren ist in Tabelle 1‑1 dargestellt.
46	
47	**Tabelle 1‑1: Unterschiede zwischen HPV-negativen und HPV-positiven Kopf-Hals Tumoren.**
48	
49	|  | HPV-positive HNSCC | HPV-negative HNSCC |
50	| --- | --- | --- |
51	| Patienteneigenschaften | Jünger, weiblich | Älter, männlich |
52	| Risikofaktoren | Promiskuitive Personen; oral-genitale/-anale Kontakte | schädlicher Alkohol- und/oder Tabakkonsum |
53	| Tumoreigenschaften | kleine Tumorgröße (T1-T2), häufig Lymphknoten-Metastasen | große Tumoren (>T2) |
54	| Tumorlokalisation | Oropharynx, v.a. Tonsillen | Regionen außerhalb um mit Durchbruch der Basalmembran und einer Neigung zu Metastasierung und Rezidiven ([Cawson & Odell, 2008](#_ENREF_18)). Den Übergang von normalem Epithel über Dysplasien zu einem invasiven Karzinom zeigt die **Abbildung _1‑2_**.
55	
56	![](images/image-a55093b6-6490-4109-8e74-21429970130c.png)
57	
58	**Abbildung 1‑2: Karzinogenes eines Mundschleimhautepithels zu einem invasivem Plattenepithelkarzinoms in der HE-Färbung(**[Argiris et al., 2008](#_ENREF_6)**).**
59	
60	### Anatomie, Histopathologie und Tumorklassifikation
61	
62	**
63	Zur Wahl des adäquaten Behandlungsverfahrens und zur exakten Dokumentation als Voraussetzung für den Vergleich von Therapieergebnissen ist eine Tumorklassifikation und eine Bestimmung der Tumorentität notwendig.
64	
65	_Anatomische Einteilung_
66	
67	Tumore im Kopf-Hals-Bereich stellen eine heterogene Gruppe von bösartigen Neubildungen des oberen Aerodigestivtrakts dar und werden in 5 unterschiedliche anatomische Bereich unterteilt, nämlich in Mundhöhle, Naso-, Oro-, Hypopharynx und Larynx.
68	
69	![](images/image-fef4b9ed-183a-457d-b6df-9995714325cc.jpeg)
70	
71	(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)