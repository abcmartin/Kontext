Text file: 8_references.md
Latest content with line numbers:
2	
3	Uncategorized References
4	
5	Ailles, L., & Prince, M. (2009). Cancer stem cells in head and neck squamous cell carcinoma. *Methods Mol Biol*, *568*, 175-193. [https://doi.org/10.1007/978-1-59745-280-9_11](https://doi.org/10.1007/978-1-59745-280-9_11)
6	
7	Al-Hajj, M., Wicha, M. S., Benito-Hernandez, A., Morrison, S. J., & Clarke, M. F. (2003). Prospective identification of tumorigenic breast cancer cells. *Proc Natl Acad Sci U S A*, *100*(7), 3983-3988. [https://doi.org/10.1073/pnas.0530291100](https://doi.org/10.1073/pnas.0530291100)
8	
9	Amin, M. B., Edge, S. B., Greene, F. L., Byrd, D. R., Brookland, R. K., Washington, M. K., Gershenwald, J. E., Compton, C. C., Hess, K. R., & Sullivan, D. C. (2018). *AJCC Cancer Staging Manual*. Springer International Publishing. [https://books.google.de/books?id=O2PyjwEACAAJ](https://books.google.de/books?id=O2PyjwEACAAJ)
10	
11	Andl, T., Kahn, T., Pfuhl, A., Nicola, T., Erber, R., Conradt, C., Klein, W., Helbig, M., Dietz, A., Weidauer, H., & Bosch, F. X. (1998). Etiological involvement of oncogenic human papillomavirus in tonsillar squamous cell carcinomas lacking retinoblastoma cell cycle control. *Cancer Res*, *58*(1), 5-13. [https://www.ncbi.nlm.nih.gov/pubmed/9426048](https://www.ncbi.nlm.nih.gov/pubmed/9426048)
12	
13	Ang, K. K., Harris, J., Wheeler, R., Weber, R., Rosenthal, D. I., Nguyen-Tan, P. F., Westra, W. H., Chung, C. H., Jordan, R. C., Lu, C., Kim, H., Axelrod, R., Silverman, C. C., Redmond, K. P., & Gillison, M. L. (2010). Human papillomavirus and survival of patients with oropharyngeal cancer. *N Engl J Med*, *363*(1), 24-35. [https://doi.org/10.1056/NEJMoa0912217](https://doi.org/10.1056/NEJMoa0912217)
14	
15	Ang, K. K., Harris, J., Wheeler, R., Weber, R., Rosenthal, D. I., Nguyen-Tân, P. F., Westra, W. H., Chung, C. H., Jordan, R. C., Lu, C., Kim, H., Axelrod, R., Silverman, C. C., Redmond, K. P., & Gillison, M. L. (2010). Human papillomavirus and survival of patients with oropharyngeal cancer. *N Engl J Med*, *363*(1), 24-35. [https://doi.org/10.1056/NEJMoa0912217](https://doi.org/10.1056/NEJMoa0912217)
16	
17	Argiris, A., Karamouzis, M. V., Raben, D., & Ferris, R. L. (2008). Head and neck cancer. *Lancet*, *371*(9625), 1695-1709. [https://doi.org/10.1016/s0140-6736(08)60728-x](https://doi.org/10.1016/s0140-6736(08)60728-x)
18	
19	Barnes, L., Pathologie, U.-S. Z. D., Eveson, J. W., Pathology, I. A. o., Sidransky, D., Organization, W. H., Cancer, I. A. f. R. o., & Reichart, P. (2005). *Pathology and Genetics of Head and Neck Tumours*. IARC Press. [https://books.google.de/books?id=mrm8hxiJ4XIC](https://books.google.de/books?id=mrm8hxiJ4XIC)
20	
21	Baumann, M., & Krause, M. (2010). CD44: a cancer stem cell-related biomarker with predictive potential for radiotherapy. *Clin Cancer Res*, *16*(21), 5091-5093. [https://doi.org/10.1158/1078-0432.CCR-10-2244](https://doi.org/10.1158/1078-0432.CCR-10-2244)
22	
23	Bernier, J., Cooper, J. S., Pajak, T. F., van Glabbeke, M., Bourhis, J., Forastiere, A., Ozsahin, E. M., Jacobs, J. R., Jassem, J., Ang, K. K., & Lefebvre, J. L. (2005). Defining risk levels in locally advanced head and neck cancers: a comparative analysis of concurrent postoperative radiation plus chemotherapy trials of the EORTC (#22931) and RTOG (# 9501). *Head Neck*, *27*(10), 843-850. [https://doi.org/10.1002/hed.20279](https://doi.org/10.1002/hed.20279)
24	
25	Biomarkers Definitions Working, G. (2001). Biomarkers and surrogate endpoints: preferred definitions and conceptual framework. *Clin Pharmacol Ther*, *69*(3), 89-95. [https://doi.org/10.1067/mcp.2001.113989](https://doi.org/10.1067/mcp.2001.113989)
26	
27	Böcker, W. (2008). *Pathologie: mit über 200 Tabellen*. Elsevier, Urban & Fischer. [https://books.google.de/books?id=_aKIKlvq3KoC](https://books.google.de/books?id=_aKIKlvq3KoC)
28	
29	Bonnet, D., & Dick, J. E. (1997). Human acute myeloid leukemia is organized as a hierarchy that originates from a primitive hematopoietic cell. *Nat Med*, *3*(7), 730-737. [https://doi.org/10.1038/nm0797-730](https://doi.org/10.1038/nm0797-730)
30	
31	Bootz, F. (2020). [Guideline on diagnosis, treatment, and follow-up of laryngeal cancer]. *Radiologe*, *60*(11), 1052-1057. [https://doi.org/10.1007/s00117-020-00760-9](https://doi.org/10.1007/s00117-020-00760-9) (S3-Leitlinie Diagnostik, Therapie und Nachsorge des Larynxkarzinoms.)
32	
33	Bouvard, V., Baan, R., Straif, K., Grosse, Y., Secretan, B., El Ghissassi, F., Benbrahim-Tallaa, L., Guha, N., Freeman, C., Galichet, L., Cogliano, V., & Group, W. H. O. I. A. f. R. o. C. M. W. (2009). A review of human carcinogens--Part B: biological agents. *Lancet Oncol*, *10*(4), 321-322. [https://doi.org/10.1016/s1470-2045(09)70096-8](https://doi.org/10.1016/s1470-2045(09)70096-8)
34	
35	Cabrera Rodriguez, J., Cacicedo, J., Giralt, J., Garcia Miragall, E., Lloret, M., Arias, F., Gonzalez Ruiz, M. A., & Contreras, J. (2018). GEORCC recommendations on target volumes in radiotherapy for Head Neck Cancer of Unkown Primary. *Crit Rev Oncol Hematol*, *130*, 51-59. [https://doi.org/10.1016/j.critrevonc.2018.07.006](https://doi.org/10.1016/j.critrevonc.2018.07.006)
36	
37	Cardesa, A., Remmele, W., Klöppel, G., Mentzel, T., Kreipe, H. H., Rudolph, P., & Slootweg, P. (2008). *Pathologie: Kopf-Hals-Region, Weichgewebstumoren, Haut*. Springer Berlin Heidelberg. [https://books.google.de/books?id=IBJSDIxrSUUC](https://books.google.de/books?id=IBJSDIxrSUUC)
38	
39	Carvalho, A. L., Nishimoto, I. N., Califano, J. A., & Kowalski, L. P. (2005). Trends in incidence and prognosis for head and neck cancer in the United States: a site-specific analysis of the SEER database. *Int J Cancer*, *114*(5), 806-816. [https://doi.org/10.1002/ijc.20740](https://doi.org/10.1002/ijc.20740)
40	
41	Cawson, R. A., & Odell, E. W. (2008). *Cawson's Essentials of Oral Pathology and Oral Medicine E-Book*. Elsevier Health Sciences. [https://books.google.de/books?id=K035mlSXAAsC](https://books.google.de/books?id=K035mlSXAAsC)
42	
43	Cawson, R. A., & Odell, E. W. (2017). *Cawson's Essentials of Oral Pathology and Oral Medicine*. Elsevier Health Sciences UK. [https://books.google.de/books?id=pAdLzQEACAAJ](https://books.google.de/books?id=pAdLzQEACAAJ)
44	
45	Chen, Y. W., Chen, K. H., Huang, P. I., Chen, Y. C., Chiou, G. Y., Lo, W. L., Tseng, L. M., Hsu, H. S., Chang, K. W., & Chiou, S. H. (2010). Cucurbitacin I suppressed stem-like property and enhanced radiation-induced apoptosis in head and neck squamous carcinoma--derived CD44(+)ALDH1(+) cells. *Mol Cancer Ther*, *9*(11), 2879-2892. [https://doi.org/10.1158/1535-7163.MCT-10-0504](https://doi.org/10.1158/1535-7163.MCT-10-0504)
46	
47	Chin, D., Boyle, G. M., Porceddu, S., Theile, D. R., Parsons, P. G., & Coman, W. B. (2006). Head and neck cancer: past, present and future. *Expert Rev Anticancer Ther*, *6*(7), 1111-1118. [https://doi.org/10.1586/14737140.6.7.1111](https://doi.org/10.1586/14737140.6.7.1111)
48	
49	Chung, C. H., & Gillison, M. L. (2009). Human papillomavirus in head and neck cancer: its role in pathogenesis and clinical implications. *Clin Cancer Res*, *15*(22), 6758-6762. [https://doi.org/10.1158/1078-0432.CCR-09-0784](https://doi.org/10.1158/1078-0432.CCR-09-0784)
50	
51	Clarke, A. R., & Meniel, V. (2006). The intestinal stem cell niche studied through conditional transgenesis. *Ernst Schering Found Symp Proc*(5), 99-108. [https://doi.org/10.1007/2789_2007_046](https://doi.org/10.1007/2789_2007_046)
52	
53	Cooper, J. S., Zhang, Q., Pajak, T. F., Forastiere, A. A., Jacobs, J., Saxman, S. B., Kish, J. A., Kim, H. E., Cmelak, A. J., Rotman, M., Lustig, R., Ensley, J. F., Thorstad, W., Schultz, C. J., Yom, S. S., & Ang, K. K. (2012). Long-term follow-up of the RTOG 9501/intergroup phase III trial: postoperative concurrent radiation therapy and chemotherapy in high-risk squamous cell carcinoma of the head and neck. *Int J Radiat Oncol Biol Phys*, *84*(5), 1198-1205. [https://doi.org/10.1016/j.ijrobp.2012.05.008](https://doi.org/10.1016/j.ijrobp.2012.05.008)
54	
55	Curado, M. P., & Boyle, P. (2013). Epidemiology of head and neck squamous cell carcinoma not related to tobacco or alcohol. *Curr Opin Oncol*, *25*(3), 229-234. [https://doi.org/10.1097/CCO.0b013e32835ff48c](https://doi.org/10.1097/CCO.0b013e32835ff48c)
56	
57	D'Souza, G., Agrawal, Y., Halpern, J., Bodison, S., & Gillison, M. L. (2009). Oral sexual behaviors associated with prevalent oral human papillomavirus infection. *J Infect Dis*, *199*(9), 1263-1269. [https://doi.org/10.1086/597755](https://doi.org/10.1086/597755)
58	
59	de Jong, M. C., Pramana, J., van der Wal, J. E., Lacko, M., Peutz-Kootstra, C. J., de Jong, J. M., Takes, R. P., Kaanders, J. H., van der Laan, B. F., Wachters, J., Jansen, J. C., Rasch, C. R., van Velthuysen, M. L., Grenman, R., Hoebers, F. J., Schuuring, E., van den Brekel, M. W., & Begg, A. C. (2010). CD44 expression predicts local recurrence after radiotherapy in larynx cancer. *Clin Cancer Res*, *16*(21), 5329-5338. [https://doi.org/10.1158/1078-0432.CCR-10-0799](https://doi.org/10.1158/1078-0432.CCR-10-0799)
60	
61	DeLellis, R. A., Sternberger, L. A., Mann, R. B., Banks, P. M., & Nakane, P. K. (1979). Immunoperoxidase technics in diagnostic pathology. Report of a workshop sponsored by the National Cancer Institute. *Am J Clin Pathol*, *71*(5), 483-488. [https://doi.org/10.1093/ajcp/71.5.483](https://doi.org/10.1093/ajcp/71.5.483)
62	
63	Duvvuri, U., & Myers, J. N. (2009). Contemporary management of oropharyngeal cancer: anatomy and physiology of the oropharynx. *Curr Probl Surg*, *46*(2), 119-184. [https://doi.org/10.1067/j.cpsurg.2008.10.003](https://doi.org/10.1067/j.cpsurg.2008.10.003)
64	
65	El-Naggar, A. K., Chan, J. K. C., Grandis, J. R., Takata, T., & Slootweg, P. J. (2017). *WHO Classification of Head and Neck Tumours*. International Agency for Research on Cancer. [https://books.google.de/books?id=EDo5MQAACAAJ](https://books.google.de/books?id=EDo5MQAACAAJ)
66	
67	Fakhry, C., Westra, W. H., Li, S., Cmelak, A., Ridge, J. A., Pinto, H., Forastiere, A., & Gillison, M. L. (2008). Improved survival of patients with human papillomavirus-positive head and neck squamous cell carcinoma in a prospective clinical trial. *J Natl Cancer Inst*, *100*(4), 261-269. [https://doi.org/10.1093/jnci/djn011](https://doi.org/10.1093/jnci/djn011)
68	
69	Ferlay, J., Colombet, M., Soerjomataram, I., Parkin, D. M., Pineros, M., Znaor, A., & Bray, F. (2021). Cancer statistics for the year 2020: An overview. *Int J Cancer*. [https://doi.org/10.1002/ijc.33588](https://doi.org/10.1002/ijc.33588)
70	
71	Gillison, M. L., D'Souza, G., Westra, W., Sugar, E., Xiao, W., Begum, S., & Viscidi, R. (2008). Distinct risk factor profiles for human papillomavirus type 16-positive and human papillomavirus type 16-negative head and neck cancers. *J Natl Cancer Inst*, *100*(6), 407-420. [https://doi.org/10.1093/jnci/djn025](https://doi.org/10.1093/jnci/djn025)
72	
73	Gillison, M. L., Koch, W. M., Capone, R. B., Spafford, M., Westra, W. H., Wu, L., Zahurak, M. L., Daniel, R. W., Viglione, M., Symer, D. E., Shah, K. V., & Sidransky, D. (2000). Evidence for a causal association between human papillomavirus and a subset of head and neck cancers. *J Natl Cancer Inst*, *92*(9), 709-720. [https://doi.org/10.1093/jnci/92.9.709](https://doi.org/10.1093/jnci/92.9.709)
74	
75	Giltnane, J. M., & Rimm, D. L. (2004). Technology insight: Identification of biomarkers with tissue microarray technology. *Nat Clin Pract Oncol*, *1*(2), 104-111. [https://doi.org/10.1038/ncponc0046](https://doi.org/10.1038/ncponc0046)
76	
77	Ginestier, C., Hur, M. H., Charafe-Jauffret, E., Monville, F., Dutcher, J., Brown, M., Jacquemier, J., Viens, P., Kleer, C. G., Liu, S., Schott, A., Hayes, D., Birnbaum, D., Wicha, M. S., & Dontu, G. (2007). ALDH1 is a marker of normal and malignant human mammary stem cells and a predictor of poor clinical outcome. *Cell Stem Cell*, *1*(5), 555-567. [https://doi.org/10.1016/j.stem.2007.08.014](https://doi.org/10.1016/j.stem.2007.08.014)
78	
79	Hafkamp, H. C., Manni, J. J., Haesevoets, A., Voogd, A. C., Schepers, M., Bot, F. J., Hopman, A. H., Ramaekers, F. C., & Speel, E. J. (2008). Marked differences in survival rate between smokers and nonsmokers with HPV 16-associated tonsillar carcinomas. *Int J Cancer*, *122*(12), 2656-2664. [https://doi.org/10.1002/ijc.23458](https://doi.org/10.1002/ijc.23458)
80	
81	Heinrich, P. C., Müller, M., & Graeve, L. (2014). *Löffler/Petrides Biochemie und Pathobiochemie*. Springer Berlin Heidelberg. [https://books.google.de/books?id=EUj_ugAACAAJ](https://books.google.de/books?id=EUj_ugAACAAJ)
82	
83	Herrmann, K., & Niedobitek, G. (2003). Epstein-Barr virus-associated carcinomas: facts and fiction. *J Pathol*, *199*(2), 140-145. [https://doi.org/10.1002/path.1296](https://doi.org/10.1002/path.1296)
84	
85	Joos, S., Nettelbeck, D. M., Reil-Held, A., Engelmann, K., Moosmann, A., Eggert, A., Hiddemann, W., Krause, M., Peters, C., Schuler, M., Schulze-Osthoff, K., Serve, H., Wick, W., Puchta, J., & Baumann, M. (2019). German Cancer Consortium (DKTK) - A national consortium for translational cancer research. *Mol Oncol*, *13*(3), 535-542. [https://doi.org/10.1002/1878-0261.12430](https://doi.org/10.1002/1878-0261.12430)
86	
87	Jütz, M., Linge, A., von Neubeck, C., Lohaus, F., Tinhofer, I., Budach, V., Gkika, E., Stuschke, M., Balermpas, P., Rödel, C., Avlar, M., Grosu, A. L., Abdollahi, A., Debus, J., Bayer, C., Belka, C., Pigorsch, S., Combs, S. E., Mönnich, D., . . . DKTK-ROG. (2015). Prognostisches Potential von CD44 als Tumorstammzellmarker für die kombinierte Radiochemotherapie des lokal fortgeschrittenen Kopf-Hals-Plattenepithelkarzinoms. Symposium Experimentelle Strahlentherapie und klinische Strahlenbiologie,
88	
89	Klijanienko, J., el-Naggar, A., Ponzio-Prion, A., Marandas, P., Micheau, C., & Caillaud, J. M. (1993). Basaloid squamous carcinoma of the head and neck. Immunohistochemical comparison with adenoid cystic carcinoma and squamous cell carcinoma. *Arch Otolaryngol Head Neck Surg*, *119*(8), 887-890. [https://doi.org/10.1001/archotol.1993.01880200093013](https://doi.org/10.1001/archotol.1993.01880200093013)
90	
91	Klussmann, J. P., Weissenborn, S. J., Wieland, U., Dries, V., Eckel, H. E., Pfister, H. J., & Fuchs, P. G. (2003). Human papillomavirus-positive tonsillar carcinomas: a different tumor entity? *Med Microbiol Immunol*, *192*(3), 129-132. [https://doi.org/10.1007/s00430-002-0126-1](https://doi.org/10.1007/s00430-002-0126-1)
92	
93	(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)