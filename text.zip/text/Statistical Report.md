# Statistical Report

This report would typically contain the results of the statistical analyses performed using the provided R script (`Ohne Titel.R`) and data (`corrected_Daten_für Martin Kopie.csv`).

**Note**: Due to environment constraints and issues with R package installations, the R script could not be executed to generate the statistical results. Therefore, this report serves as a placeholder.

## Planned Analyses (from Ohne Titel.R)

### a. Descriptive Analysis
*   Distribution of patient characteristics (e.g., Age)
*   Distribution of tumor characteristics (e.g., Tumor Stage)
*   Distribution of treatment characteristics (e.g., Treatment Type)

### b. Event-Time Analyses
*   Loco-regional tumor control (`LokoRegionaleKontrolle`)
*   Distant metastasis-free survival (`FernMetastasenFrei`)
*   Overall survival (`GesamtUeberleben`)

### c. Multivariate Analyses
*   Cox Proportional Hazards Model for overall survival, considering `CD44_Expression`, `HPV16_DNA_Status`, `Alter`, `Geschlecht`, and `TumorStadium`.

